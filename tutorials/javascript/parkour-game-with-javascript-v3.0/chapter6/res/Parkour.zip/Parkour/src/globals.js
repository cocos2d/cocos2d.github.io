var g_groundHeight = 57;
var g_runnerStartX = 80;