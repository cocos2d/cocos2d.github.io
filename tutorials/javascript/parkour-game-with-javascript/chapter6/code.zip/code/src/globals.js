var g_groundHight = 57;
var g_runnerStartX = 80;