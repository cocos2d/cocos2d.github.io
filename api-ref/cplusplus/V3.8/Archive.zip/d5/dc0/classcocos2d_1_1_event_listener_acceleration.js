var classcocos2d_1_1_event_listener_acceleration =
[
    [ "~EventListenerAcceleration", "d5/dc0/classcocos2d_1_1_event_listener_acceleration.html#a6122a6f06f11e800b1df289cdc603910", null ],
    [ "clone", "d5/dc0/classcocos2d_1_1_event_listener_acceleration.html#a5482bd8e245f0226244df3d68d7ff44b", null ],
    [ "checkAvailable", "d5/dc0/classcocos2d_1_1_event_listener_acceleration.html#ab93f0dcb45008d86dd3d2b93298f0ae4", null ]
];