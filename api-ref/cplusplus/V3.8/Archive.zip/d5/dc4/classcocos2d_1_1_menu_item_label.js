var classcocos2d_1_1_menu_item_label =
[
    [ "setString", "d5/dc4/classcocos2d_1_1_menu_item_label.html#a65731bab45cf0ef8790a817e8f2e2867", null ],
    [ "getDisabledColor", "d5/dc4/classcocos2d_1_1_menu_item_label.html#a9c79c48d23195f82d7179d6c7fb5bb44", null ],
    [ "setDisabledColor", "d5/dc4/classcocos2d_1_1_menu_item_label.html#a06b06fdc6c78e462f70853b43ef0cb19", null ],
    [ "getLabel", "d5/dc4/classcocos2d_1_1_menu_item_label.html#a388498975bcb3305fdcb9e62536e608d", null ],
    [ "setLabel", "d5/dc4/classcocos2d_1_1_menu_item_label.html#aa72dc5b9c6f1abe53d409af7a175107c", null ],
    [ "activate", "d5/dc4/classcocos2d_1_1_menu_item_label.html#a5afbf8bbd50c88f1530a634b075e12d9", null ],
    [ "selected", "d5/dc4/classcocos2d_1_1_menu_item_label.html#a14faaa485b11904c0d1cef14fbe31fed", null ],
    [ "unselected", "d5/dc4/classcocos2d_1_1_menu_item_label.html#a9af51b3c7c21429a13ac25dc20e0a46d", null ],
    [ "setEnabled", "d5/dc4/classcocos2d_1_1_menu_item_label.html#a8c38539978869f3bde8e3b35ddf5b266", null ],
    [ "initWithLabel", "d5/dc4/classcocos2d_1_1_menu_item_label.html#a238bda14cded0d2ff7fb66f98e2dd6eb", null ],
    [ "initWithLabel", "d5/dc4/classcocos2d_1_1_menu_item_label.html#a622803e9aa97907d26c8b3863c9b1791", null ]
];