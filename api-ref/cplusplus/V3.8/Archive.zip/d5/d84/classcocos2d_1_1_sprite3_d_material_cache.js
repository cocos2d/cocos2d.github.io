var classcocos2d_1_1_sprite3_d_material_cache =
[
    [ "addSprite3DMaterial", "d5/d84/classcocos2d_1_1_sprite3_d_material_cache.html#a3445fdb4d3e164d87aa8a020afcc4710", null ],
    [ "getSprite3DMaterial", "d5/d84/classcocos2d_1_1_sprite3_d_material_cache.html#ac9d9eef8f41187518a5d5bad4757fb40", null ],
    [ "removeAllSprite3DMaterial", "d5/d84/classcocos2d_1_1_sprite3_d_material_cache.html#aaf5b54c48da9cab3b0311e055cf9dd88", null ],
    [ "removeUnusedSprite3DMaterial", "d5/d84/classcocos2d_1_1_sprite3_d_material_cache.html#a9b543b5188f96cc38d19d7a1bad82c7b", null ]
];