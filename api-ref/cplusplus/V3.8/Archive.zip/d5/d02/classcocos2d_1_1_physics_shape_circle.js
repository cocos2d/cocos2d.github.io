var classcocos2d_1_1_physics_shape_circle =
[
    [ "calculateDefaultMoment", "d5/d02/classcocos2d_1_1_physics_shape_circle.html#a029fff81aa1cf55b1eaeb88fe8af03cd", null ],
    [ "getRadius", "d5/d02/classcocos2d_1_1_physics_shape_circle.html#a1f582583ca261741e5157776105d6f17", null ],
    [ "getOffset", "d5/d02/classcocos2d_1_1_physics_shape_circle.html#a9c7ad5f79b2ddcc2dd81b18387bf2753", null ]
];