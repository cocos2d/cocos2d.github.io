var structcocos2d_1_1_vertex_attrib =
[
    [ "index", "d5/d35/structcocos2d_1_1_vertex_attrib.html#af7ca775b6d9354291c4d7d01b8b2a8bc", null ],
    [ "size", "d5/d35/structcocos2d_1_1_vertex_attrib.html#a0208b298f4c65e680a58434efb699fe8", null ],
    [ "type", "d5/d35/structcocos2d_1_1_vertex_attrib.html#a579922e668b544baacb0839db8d6ae37", null ],
    [ "name", "d5/d35/structcocos2d_1_1_vertex_attrib.html#a9b45b3e13bd9167aab02e17e08916231", null ]
];