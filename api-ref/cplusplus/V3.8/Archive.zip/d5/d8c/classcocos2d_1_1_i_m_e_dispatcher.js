var classcocos2d_1_1_i_m_e_dispatcher =
[
    [ "dispatchInsertText", "d5/d8c/classcocos2d_1_1_i_m_e_dispatcher.html#a28b6a82b2bda28c9c213f01112c403e5", null ],
    [ "dispatchDeleteBackward", "d5/d8c/classcocos2d_1_1_i_m_e_dispatcher.html#a5acd5dc8a188288dc2771f6763fcbfb7", null ],
    [ "getContentText", "d5/d8c/classcocos2d_1_1_i_m_e_dispatcher.html#a38b917e1b55290709a172fbc01cfe5dd", null ]
];