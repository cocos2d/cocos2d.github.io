var classcocos2d_1_1_frustum =
[
    [ "Frustum", "d5/d8a/classcocos2d_1_1_frustum.html#a6768c58ca61f1f5d3b4a0192abd0695b", null ],
    [ "initFrustum", "d5/d8a/classcocos2d_1_1_frustum.html#af9f017eed8d5495c84e1477ce3e9120e", null ],
    [ "isOutOfFrustum", "d5/d8a/classcocos2d_1_1_frustum.html#abbfedfbc69f1e9df9d638354c12342f7", null ],
    [ "isOutOfFrustum", "d5/d8a/classcocos2d_1_1_frustum.html#a40d1d834920106f333f49a5bb7b83394", null ],
    [ "setClipZ", "d5/d8a/classcocos2d_1_1_frustum.html#a5cb9988a1f246efb8219deb60290e3f4", null ]
];