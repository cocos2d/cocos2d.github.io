var classcocos2d_1_1ui_1_1_scroll_view_bar =
[
    [ "ScrollViewBar", "d5/d43/classcocos2d_1_1ui_1_1_scroll_view_bar.html#a6a7b9637b23c9a75935c118b6023b814", null ],
    [ "~ScrollViewBar", "d5/d43/classcocos2d_1_1ui_1_1_scroll_view_bar.html#a329bfc11f263e096bd44a27136bd8285", null ],
    [ "setPositionFromCorner", "d5/d43/classcocos2d_1_1ui_1_1_scroll_view_bar.html#a5ba3df8bd03c9bdd067d9072458afad1", null ],
    [ "getPositionFromCorner", "d5/d43/classcocos2d_1_1ui_1_1_scroll_view_bar.html#a17f3fdc4144b46657e7dee16c79304f7", null ],
    [ "setWidth", "d5/d43/classcocos2d_1_1ui_1_1_scroll_view_bar.html#a21926c99f9ed7ba46fb67cf6f5095312", null ],
    [ "getWidth", "d5/d43/classcocos2d_1_1ui_1_1_scroll_view_bar.html#a1abb04c6637e0fca05587a36d9ea6b5e", null ],
    [ "setAutoHideEnabled", "d5/d43/classcocos2d_1_1ui_1_1_scroll_view_bar.html#a6c4f8e74ccf7903ab79cabf9d60d57e5", null ],
    [ "isAutoHideEnabled", "d5/d43/classcocos2d_1_1ui_1_1_scroll_view_bar.html#abf502838e1f5b20a63d2c07cbd680cca", null ],
    [ "setAutoHideTime", "d5/d43/classcocos2d_1_1ui_1_1_scroll_view_bar.html#a0a0ceab5e6e09e0bb1656a2f41ad0bca", null ],
    [ "getAutoHideTime", "d5/d43/classcocos2d_1_1ui_1_1_scroll_view_bar.html#a87ab10a1db6cf4e88bf68e10675bed87", null ],
    [ "onScrolled", "d5/d43/classcocos2d_1_1ui_1_1_scroll_view_bar.html#a70d468b64961d37a63348137129bf7fe", null ],
    [ "onEnter", "d5/d43/classcocos2d_1_1ui_1_1_scroll_view_bar.html#afc7cfcc21d71b281894ff0800f4a9081", null ],
    [ "update", "d5/d43/classcocos2d_1_1ui_1_1_scroll_view_bar.html#ae85106fe7f1a33d5e0b2c35de3795a39", null ],
    [ "onTouchBegan", "d5/d43/classcocos2d_1_1ui_1_1_scroll_view_bar.html#a02c95746401f394975314b7b3adf432f", null ],
    [ "onTouchEnded", "d5/d43/classcocos2d_1_1ui_1_1_scroll_view_bar.html#a3b6789123f885a86137363849c0d0ed8", null ]
];