var classcocos2d_1_1_skybox =
[
    [ "Skybox", "d5/d29/classcocos2d_1_1_skybox.html#a61fa372aba44a93c4b48fd1bc84e6f83", null ],
    [ "~Skybox", "d5/d29/classcocos2d_1_1_skybox.html#a1474c0294a7be98198c366a758154bbb", null ],
    [ "setTexture", "d5/d29/classcocos2d_1_1_skybox.html#ab64b125eaaec2f65a0b0c3162b8cb3e6", null ],
    [ "draw", "d5/d29/classcocos2d_1_1_skybox.html#a0f59730fa0bd109f318e0a18bb4f8945", null ],
    [ "reload", "d5/d29/classcocos2d_1_1_skybox.html#af0de4b4127be745f3a835f316c6d2d03", null ],
    [ "init", "d5/d29/classcocos2d_1_1_skybox.html#aece461389d41c7de591b2bcd99a3e3e2", null ],
    [ "init", "d5/d29/classcocos2d_1_1_skybox.html#a87fbc9fd1a8bf48bbc53d251a22f3062", null ]
];