var classcocos2d_1_1_particle_flower =
[
    [ "initWithTotalParticles", "d5/db5/classcocos2d_1_1_particle_flower.html#ac7e269df79e2dd7599ae15c4ec037942", null ]
];