var structcocos2d_1_1_font_definition =
[
    [ "_fontName", "d5/d45/structcocos2d_1_1_font_definition.html#acb14b9552a4b9d00c844ac3013b14db3", null ],
    [ "_fontSize", "d5/d45/structcocos2d_1_1_font_definition.html#ad27640c2b7563689395cc436abcb77bd", null ],
    [ "_alignment", "d5/d45/structcocos2d_1_1_font_definition.html#a392fa20596e9608b730b2e8de5f80be6", null ],
    [ "_vertAlignment", "d5/d45/structcocos2d_1_1_font_definition.html#ada0c023c829d3b2958c570bf92832882", null ],
    [ "_dimensions", "d5/d45/structcocos2d_1_1_font_definition.html#afeda0bbe5ee090b4c11175fd46c16332", null ],
    [ "_fontFillColor", "d5/d45/structcocos2d_1_1_font_definition.html#a07494ebbac78077a2455ecd6b9ca31bf", null ],
    [ "_fontAlpha", "d5/d45/structcocos2d_1_1_font_definition.html#af760b73abade7cdf0abbd4b0f0dcece6", null ],
    [ "_shadow", "d5/d45/structcocos2d_1_1_font_definition.html#a042ec51fc090c27487f14da781d73d8c", null ],
    [ "_stroke", "d5/d45/structcocos2d_1_1_font_definition.html#a45a6b867ae40bded50e743fef63197b9", null ]
];