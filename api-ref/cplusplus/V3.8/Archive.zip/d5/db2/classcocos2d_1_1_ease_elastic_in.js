var classcocos2d_1_1_ease_elastic_in =
[
    [ "update", "d5/db2/classcocos2d_1_1_ease_elastic_in.html#a751ebb37cca9cecea95c8160529b097c", null ],
    [ "clone", "d5/db2/classcocos2d_1_1_ease_elastic_in.html#a3f7e1eead12af619574a5bfa6e9ee0e5", null ],
    [ "reverse", "d5/db2/classcocos2d_1_1_ease_elastic_in.html#a3e49d406ecbcf9c052ff1ead85be9056", null ]
];