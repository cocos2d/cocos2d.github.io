var classcocos2d_1_1_animate3_d =
[
    [ "stop", "d5/d11/classcocos2d_1_1_animate3_d.html#a1306e29fda504409b52d24e2002fbee3", null ],
    [ "step", "d5/d11/classcocos2d_1_1_animate3_d.html#a88ce9736d5be5a3657eff3fe52777501", null ],
    [ "startWithTarget", "d5/d11/classcocos2d_1_1_animate3_d.html#a82f24562dbde467eaa45c5a075678bd3", null ],
    [ "reverse", "d5/d11/classcocos2d_1_1_animate3_d.html#a9174af7ea62baa1fe976441545fc2b4d", null ],
    [ "clone", "d5/d11/classcocos2d_1_1_animate3_d.html#a01d3a89e163f70af55a1847b918a231f", null ],
    [ "update", "d5/d11/classcocos2d_1_1_animate3_d.html#ac3a04caa0eb489bf6289045d51b1d577", null ],
    [ "getSpeed", "d5/d11/classcocos2d_1_1_animate3_d.html#a4ab87c5df7c3eadd17b318a426773fcb", null ],
    [ "getWeight", "d5/d11/classcocos2d_1_1_animate3_d.html#aa17d38dafd3d75c59f0609f037fbe5ae", null ],
    [ "setOriginInterval", "d5/d11/classcocos2d_1_1_animate3_d.html#a97009c5b687c4fab7cf5e1000a729990", null ],
    [ "getPlayBack", "d5/d11/classcocos2d_1_1_animate3_d.html#a2b088cf2ad025d886778b0bb6a810f5d", null ],
    [ "setQuality", "d5/d11/classcocos2d_1_1_animate3_d.html#a269355f6a5f4a01ff36869a44c328b39", null ],
    [ "getQuality", "d5/d11/classcocos2d_1_1_animate3_d.html#aa8e5166bcf24c1531272df087a85b6ed", null ],
    [ "init", "d5/d11/classcocos2d_1_1_animate3_d.html#a5108f532415cf6ea10174a54d82d8a7f", null ]
];