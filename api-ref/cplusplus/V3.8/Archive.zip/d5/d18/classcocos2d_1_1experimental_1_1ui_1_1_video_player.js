var classcocos2d_1_1experimental_1_1ui_1_1_video_player =
[
    [ "ccVideoPlayerCallback", "d5/d18/classcocos2d_1_1experimental_1_1ui_1_1_video_player.html#a3fe507f03c511f4d9b6d0952114fe5a0", null ],
    [ "EventType", "dd/df1/group__ui.html#ga2628ea8d12e8b2563c32f05dc7fff6fa", null ],
    [ "CREATE_FUNC", "d5/d18/classcocos2d_1_1experimental_1_1ui_1_1_video_player.html#a6410813927764a7d0ceaf1475101c956", null ],
    [ "setFileName", "d5/d18/classcocos2d_1_1experimental_1_1ui_1_1_video_player.html#a2d75f3ce8f72f95651dadb74dbd6affe", null ],
    [ "getFileName", "d5/d18/classcocos2d_1_1experimental_1_1ui_1_1_video_player.html#a4b2b2793d8d8f3f6a4713c99f1953838", null ],
    [ "setURL", "d5/d18/classcocos2d_1_1experimental_1_1ui_1_1_video_player.html#a5e9bf0456e3de05a07c3f18f5271ef96", null ],
    [ "getURL", "d5/d18/classcocos2d_1_1experimental_1_1ui_1_1_video_player.html#ac51b20c370a61d8f9fec53402743dfec", null ],
    [ "play", "d5/d18/classcocos2d_1_1experimental_1_1ui_1_1_video_player.html#a3d2c2e0ac8d63c418db8aecfd91da95c", null ],
    [ "pause", "d5/d18/classcocos2d_1_1experimental_1_1ui_1_1_video_player.html#adcb09415ee897ee936974bdbeefedca5", null ],
    [ "resume", "d5/d18/classcocos2d_1_1experimental_1_1ui_1_1_video_player.html#aa220a4cdc8fc9db870a62bd667575fb8", null ],
    [ "stop", "d5/d18/classcocos2d_1_1experimental_1_1ui_1_1_video_player.html#ae92ae13a136435391be883fd6f0f5c8c", null ],
    [ "seekTo", "d5/d18/classcocos2d_1_1experimental_1_1ui_1_1_video_player.html#a73c9dd10a108110a7c360f8246a95ab7", null ],
    [ "isPlaying", "d5/d18/classcocos2d_1_1experimental_1_1ui_1_1_video_player.html#ab3ae73b644590edd295095770c84cbc9", null ],
    [ "setKeepAspectRatioEnabled", "d5/d18/classcocos2d_1_1experimental_1_1ui_1_1_video_player.html#aa57cd5a6b5c7e9bdb33a40e2fb824297", null ],
    [ "isKeepAspectRatioEnabled", "d5/d18/classcocos2d_1_1experimental_1_1ui_1_1_video_player.html#afd6bd9c74f492ed6702e0e1953bdeaa2", null ],
    [ "setFullScreenEnabled", "d5/d18/classcocos2d_1_1experimental_1_1ui_1_1_video_player.html#af65300eab2d3650d486ffbfd3f6759cc", null ],
    [ "isFullScreenEnabled", "d5/d18/classcocos2d_1_1experimental_1_1ui_1_1_video_player.html#a4f6656db029ee503d72ca0e6d2d1cca3", null ],
    [ "addEventListener", "d5/d18/classcocos2d_1_1experimental_1_1ui_1_1_video_player.html#a300190bf6d47f5c889d10f8ce159babb", null ],
    [ "onPlayEvent", "d5/d18/classcocos2d_1_1experimental_1_1ui_1_1_video_player.html#a5857c1e516ec1a69ea16c4a4bd5a713d", null ],
    [ "setVisible", "d5/d18/classcocos2d_1_1experimental_1_1ui_1_1_video_player.html#a4d9d85566e9111fa845b66b32c0b0378", null ],
    [ "draw", "d5/d18/classcocos2d_1_1experimental_1_1ui_1_1_video_player.html#a0f59730fa0bd109f318e0a18bb4f8945", null ]
];