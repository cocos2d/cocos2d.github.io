var classcocos2d_1_1_ease_back_out =
[
    [ "update", "d5/d93/classcocos2d_1_1_ease_back_out.html#a751ebb37cca9cecea95c8160529b097c", null ],
    [ "clone", "d5/d93/classcocos2d_1_1_ease_back_out.html#a07d92a6d8ab41361f117dfffe10039fe", null ],
    [ "reverse", "d5/d93/classcocos2d_1_1_ease_back_out.html#ae4358774e2467d56e2d5c2802ec042bd", null ]
];