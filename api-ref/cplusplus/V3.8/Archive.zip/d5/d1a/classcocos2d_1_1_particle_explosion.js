var classcocos2d_1_1_particle_explosion =
[
    [ "initWithTotalParticles", "d5/d1a/classcocos2d_1_1_particle_explosion.html#ac7e269df79e2dd7599ae15c4ec037942", null ]
];