var classcocos2d_1_1_particle_system_quad =
[
    [ "setDisplayFrame", "d5/d59/classcocos2d_1_1_particle_system_quad.html#a61a1c6e9b3e7f4b5bbbddf0883fe9fbf", null ],
    [ "setTextureWithRect", "d5/d59/classcocos2d_1_1_particle_system_quad.html#a1c2cdc1ebde36d0b3a2966e1db2e4930", null ],
    [ "listenRendererRecreated", "d5/d59/classcocos2d_1_1_particle_system_quad.html#a0268c1714ab6f48735e31182d3d9f322", null ],
    [ "updateQuadWithParticle", "d5/d59/classcocos2d_1_1_particle_system_quad.html#ade8be2b0b78659e809935569c2b2315b", null ],
    [ "postStep", "d5/d59/classcocos2d_1_1_particle_system_quad.html#aa400cdff4cfb3d084f3308946b3d5d67", null ],
    [ "draw", "d5/d59/classcocos2d_1_1_particle_system_quad.html#a0f59730fa0bd109f318e0a18bb4f8945", null ],
    [ "setBatchNode", "d5/d59/classcocos2d_1_1_particle_system_quad.html#a66a54a3aa44cf34c8cd085c9965a5459", null ],
    [ "setTotalParticles", "d5/d59/classcocos2d_1_1_particle_system_quad.html#abb36abb13ccf98bd1ca425bcbcc3d6ad", null ],
    [ "getDescription", "d5/d59/classcocos2d_1_1_particle_system_quad.html#a52b7741f1ccd38d665e153882b7dc0dd", null ],
    [ "initWithTotalParticles", "d5/d59/classcocos2d_1_1_particle_system_quad.html#a1af6225c1f555b07d207e2f74d56df49", null ]
];