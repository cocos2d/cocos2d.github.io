var classcocos2d_1_1_physics_contact =
[
    [ "getShapeA", "d5/d22/classcocos2d_1_1_physics_contact.html#a5a122a73f30a05d4afdfcafad4602588", null ],
    [ "getShapeB", "d5/d22/classcocos2d_1_1_physics_contact.html#a065998e325552955c26d6d18cb8c4531", null ],
    [ "getContactData", "d5/d22/classcocos2d_1_1_physics_contact.html#a5bbb9048b62c29f4abed76214b557c76", null ],
    [ "getPreContactData", "d5/d22/classcocos2d_1_1_physics_contact.html#ab20d82d1b31d5f89a50796b4f9711ff1", null ],
    [ "getData", "d5/d22/classcocos2d_1_1_physics_contact.html#a264b7ba091e1d269eb2f4bc62a66f515", null ],
    [ "setData", "d5/d22/classcocos2d_1_1_physics_contact.html#a0e9f5142b6aa4d7c3695ef62a9e348b3", null ],
    [ "getEventCode", "d5/d22/classcocos2d_1_1_physics_contact.html#a4e97e539bb61fc954d558e55dedbcc2f", null ]
];