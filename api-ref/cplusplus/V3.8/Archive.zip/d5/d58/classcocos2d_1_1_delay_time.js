var classcocos2d_1_1_delay_time =
[
    [ "update", "d5/d58/classcocos2d_1_1_delay_time.html#a751ebb37cca9cecea95c8160529b097c", null ],
    [ "reverse", "d5/d58/classcocos2d_1_1_delay_time.html#a9900306b7430b9cb74bd87a20e7a03f0", null ],
    [ "clone", "d5/d58/classcocos2d_1_1_delay_time.html#abf6e52f8b1898f3f7582f2d15ea4e02d", null ]
];