var classcocos2d_1_1_waves =
[
    [ "getAmplitude", "d5/d54/classcocos2d_1_1_waves.html#a2eebe6231e08688ab746f9bef40757b5", null ],
    [ "setAmplitude", "d5/d54/classcocos2d_1_1_waves.html#acd4492eedc1644fc7e48deb4a271a065", null ],
    [ "getAmplitudeRate", "d5/d54/classcocos2d_1_1_waves.html#a85bc1a53737f46d910e729330d94337e", null ],
    [ "setAmplitudeRate", "d5/d54/classcocos2d_1_1_waves.html#a0c6226cda8f33fb69a4d3ec11c8b1774", null ],
    [ "clone", "d5/d54/classcocos2d_1_1_waves.html#a56151993c614de78de27144713591927", null ],
    [ "update", "d5/d54/classcocos2d_1_1_waves.html#a751ebb37cca9cecea95c8160529b097c", null ],
    [ "initWithDuration", "d5/d54/classcocos2d_1_1_waves.html#a2573f3a0596aab29e1ca8ac94d3727bb", null ]
];