var classcocos2d_1_1_vertex_attrib_binding =
[
    [ "bind", "d0/d99/classcocos2d_1_1_vertex_attrib_binding.html#a51d1656e5add9a86bc733cc3c21ae81e", null ],
    [ "unbind", "d0/d99/classcocos2d_1_1_vertex_attrib_binding.html#af294915156f1e30f1d2e574dccc87945", null ],
    [ "getVertexAttribsFlags", "d0/d99/classcocos2d_1_1_vertex_attrib_binding.html#a6bf007d428641054e5b11abbd6ba18d5", null ]
];