var classcocos2d_1_1network_1_1_web_socket =
[
    [ "ErrorCode", "db/d3a/group__network.html#ga59e56af19e754a6aa26a612ebf91d05f", [
      [ "CONNECTION_FAILURE", "db/d3a/group__network.html#gga59e56af19e754a6aa26a612ebf91d05fa9ce818a4b52e8a8c6539fe6391392369", null ],
      [ "UNKNOWN", "db/d3a/group__network.html#gga59e56af19e754a6aa26a612ebf91d05fa696b031073e74bf2cb98e5ef201d4aa3", null ]
    ] ],
    [ "State", "db/d3a/group__network.html#ga5d74787dedbc4e11c1ab15bf487e61f8", [
      [ "OPEN", "db/d3a/group__network.html#gga5d74787dedbc4e11c1ab15bf487e61f8aa38bd5138bf35514df41a1795ebbf5c3", null ],
      [ "CLOSING", "db/d3a/group__network.html#gga5d74787dedbc4e11c1ab15bf487e61f8aa71a44c4c886bfc66b1edd511e6a677e", null ],
      [ "CLOSED", "db/d3a/group__network.html#gga5d74787dedbc4e11c1ab15bf487e61f8a110ccf2f5d2ff4eda1fd1a494293467d", null ]
    ] ],
    [ "WebSocket", "d0/dab/classcocos2d_1_1network_1_1_web_socket.html#aa3cb16933bc8224409ae525bbf821a79", null ],
    [ "~WebSocket", "d0/dab/classcocos2d_1_1network_1_1_web_socket.html#ad679d104906d3c4969770e5364341d01", null ],
    [ "init", "d0/dab/classcocos2d_1_1network_1_1_web_socket.html#af8bb57747592fd68700788376723da97", null ],
    [ "send", "d0/dab/classcocos2d_1_1network_1_1_web_socket.html#a4d274fdc2a242187da42dcd82cd593ec", null ],
    [ "send", "d0/dab/classcocos2d_1_1network_1_1_web_socket.html#a5094711b8acd973c0d29ff3268a3b556", null ],
    [ "close", "d0/dab/classcocos2d_1_1network_1_1_web_socket.html#a5ae591df94fc66ccb85cbb6565368bca", null ],
    [ "getReadyState", "d0/dab/classcocos2d_1_1network_1_1_web_socket.html#af87a9083db81f05363029b807fc080c8", null ]
];