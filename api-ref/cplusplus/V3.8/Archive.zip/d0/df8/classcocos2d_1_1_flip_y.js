var classcocos2d_1_1_flip_y =
[
    [ "update", "d0/df8/classcocos2d_1_1_flip_y.html#a751ebb37cca9cecea95c8160529b097c", null ],
    [ "reverse", "d0/df8/classcocos2d_1_1_flip_y.html#a7710c46224418b1f4f5e227f2da3cab7", null ],
    [ "clone", "d0/df8/classcocos2d_1_1_flip_y.html#a302869b9ede4edaec9f459b21770c6a3", null ],
    [ "initWithFlipY", "d0/df8/classcocos2d_1_1_flip_y.html#a8b2b13788190ab34cc566b6a19f266ab", null ]
];