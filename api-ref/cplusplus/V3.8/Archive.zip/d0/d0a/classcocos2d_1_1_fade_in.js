var classcocos2d_1_1_fade_in =
[
    [ "startWithTarget", "d0/d0a/classcocos2d_1_1_fade_in.html#a82f24562dbde467eaa45c5a075678bd3", null ],
    [ "clone", "d0/d0a/classcocos2d_1_1_fade_in.html#a4294a559774cf4ed677ec6d0da9f2c1b", null ],
    [ "reverse", "d0/d0a/classcocos2d_1_1_fade_in.html#a3879a4b096365bb34041cf942318897f", null ]
];