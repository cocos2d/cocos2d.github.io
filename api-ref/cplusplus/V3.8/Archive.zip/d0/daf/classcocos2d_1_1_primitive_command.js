var classcocos2d_1_1_primitive_command =
[
    [ "PrimitiveCommand", "d0/daf/classcocos2d_1_1_primitive_command.html#aa8824c7c24f88c0e2e5cc5b546f8f6bf", null ],
    [ "init", "d0/daf/classcocos2d_1_1_primitive_command.html#a46af4dc93cc1a667f121470f79fed053", null ],
    [ "getMaterialID", "d0/daf/classcocos2d_1_1_primitive_command.html#aedf29f2f465e8495a474fcf8c8b0a05d", null ],
    [ "getTextureID", "d0/daf/classcocos2d_1_1_primitive_command.html#a79c93b6ea09675637b2fe115791e0c8d", null ],
    [ "getGLProgramState", "d0/daf/classcocos2d_1_1_primitive_command.html#ab46b15fee7689524195a544dc7ff29bd", null ],
    [ "getBlendType", "d0/daf/classcocos2d_1_1_primitive_command.html#ae6f903b9e0fd0dfe3eb2c0e202f4566b", null ],
    [ "getModelView", "d0/daf/classcocos2d_1_1_primitive_command.html#ae196964979f4ed337a0aebab890917b9", null ],
    [ "execute", "d0/daf/classcocos2d_1_1_primitive_command.html#a3ef44ffb52226b9cf2c69839f373abe3", null ]
];