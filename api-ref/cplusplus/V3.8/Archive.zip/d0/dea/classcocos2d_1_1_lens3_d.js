var classcocos2d_1_1_lens3_d =
[
    [ "getLensEffect", "d0/dea/classcocos2d_1_1_lens3_d.html#a9201dddcdb71d6324f3880cdbdbbe058", null ],
    [ "setLensEffect", "d0/dea/classcocos2d_1_1_lens3_d.html#abe95124acd2d2908b8988e399aa3c4af", null ],
    [ "setConcave", "d0/dea/classcocos2d_1_1_lens3_d.html#abe25ed89260f3d865ad125889499dffd", null ],
    [ "getPosition", "d0/dea/classcocos2d_1_1_lens3_d.html#a33dfb150cacb0ddb44a5ff242ed65575", null ],
    [ "setPosition", "d0/dea/classcocos2d_1_1_lens3_d.html#a5f972b6a30174047c52ab40d26e720ce", null ],
    [ "clone", "d0/dea/classcocos2d_1_1_lens3_d.html#a921cc242aa31f7edf51f57e11169206b", null ],
    [ "update", "d0/dea/classcocos2d_1_1_lens3_d.html#a751ebb37cca9cecea95c8160529b097c", null ],
    [ "initWithDuration", "d0/dea/classcocos2d_1_1_lens3_d.html#a9b3f099535cddd05704050d3abc9e451", null ]
];