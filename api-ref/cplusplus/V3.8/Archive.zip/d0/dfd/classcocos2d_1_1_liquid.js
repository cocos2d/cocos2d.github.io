var classcocos2d_1_1_liquid =
[
    [ "getAmplitude", "d0/dfd/classcocos2d_1_1_liquid.html#a2eebe6231e08688ab746f9bef40757b5", null ],
    [ "setAmplitude", "d0/dfd/classcocos2d_1_1_liquid.html#acd4492eedc1644fc7e48deb4a271a065", null ],
    [ "getAmplitudeRate", "d0/dfd/classcocos2d_1_1_liquid.html#a85bc1a53737f46d910e729330d94337e", null ],
    [ "setAmplitudeRate", "d0/dfd/classcocos2d_1_1_liquid.html#a0c6226cda8f33fb69a4d3ec11c8b1774", null ],
    [ "clone", "d0/dfd/classcocos2d_1_1_liquid.html#aad4f072b46b1b101799122c9397f5ffc", null ],
    [ "update", "d0/dfd/classcocos2d_1_1_liquid.html#a751ebb37cca9cecea95c8160529b097c", null ],
    [ "initWithDuration", "d0/dfd/classcocos2d_1_1_liquid.html#ab2b03d3c5e5eee53d53ed83ef12795c1", null ]
];