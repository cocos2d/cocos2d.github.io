var classcocos2d_1_1_shuffle_tiles =
[
    [ "startWithTarget", "d0/d3b/classcocos2d_1_1_shuffle_tiles.html#a82f24562dbde467eaa45c5a075678bd3", null ],
    [ "update", "d0/d3b/classcocos2d_1_1_shuffle_tiles.html#a751ebb37cca9cecea95c8160529b097c", null ],
    [ "clone", "d0/d3b/classcocos2d_1_1_shuffle_tiles.html#a380eff5eb01e890c6617f91a5cf23b98", null ],
    [ "initWithDuration", "d0/d3b/classcocos2d_1_1_shuffle_tiles.html#a30d73356dc7f38bc682f83fb2875d139", null ]
];