var classcocos2d_1_1_transition_flip_x =
[
    [ "onEnter", "d0/d4f/classcocos2d_1_1_transition_flip_x.html#afc7cfcc21d71b281894ff0800f4a9081", null ]
];