var classcocos2d_1_1_rotate_by =
[
    [ "clone", "d0/d28/classcocos2d_1_1_rotate_by.html#af39bf2a0b300ccbdeb9c1020d5ef4d08", null ],
    [ "reverse", "d0/d28/classcocos2d_1_1_rotate_by.html#a6656a3d0d3eef262e5de9f6c54333a26", null ],
    [ "startWithTarget", "d0/d28/classcocos2d_1_1_rotate_by.html#a82f24562dbde467eaa45c5a075678bd3", null ],
    [ "update", "d0/d28/classcocos2d_1_1_rotate_by.html#a751ebb37cca9cecea95c8160529b097c", null ],
    [ "initWithDuration", "d0/d28/classcocos2d_1_1_rotate_by.html#ac853ed2e414c5f8b79dcece2f7b60e88", null ],
    [ "initWithDuration", "d0/d28/classcocos2d_1_1_rotate_by.html#a15f8839a2e7d6f6dc201e778e7f1a421", null ]
];