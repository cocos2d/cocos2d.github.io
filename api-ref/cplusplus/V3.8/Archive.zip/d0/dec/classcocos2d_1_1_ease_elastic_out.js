var classcocos2d_1_1_ease_elastic_out =
[
    [ "update", "d0/dec/classcocos2d_1_1_ease_elastic_out.html#a751ebb37cca9cecea95c8160529b097c", null ],
    [ "clone", "d0/dec/classcocos2d_1_1_ease_elastic_out.html#ae30906f03d5e717d9353b5e140b3cea9", null ],
    [ "reverse", "d0/dec/classcocos2d_1_1_ease_elastic_out.html#a3e49d406ecbcf9c052ff1ead85be9056", null ]
];