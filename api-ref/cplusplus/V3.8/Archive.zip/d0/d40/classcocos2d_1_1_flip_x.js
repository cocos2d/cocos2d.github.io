var classcocos2d_1_1_flip_x =
[
    [ "update", "d0/d40/classcocos2d_1_1_flip_x.html#a751ebb37cca9cecea95c8160529b097c", null ],
    [ "reverse", "d0/d40/classcocos2d_1_1_flip_x.html#aea5959e23bfef6ef834c6f9e80435bce", null ],
    [ "clone", "d0/d40/classcocos2d_1_1_flip_x.html#a3bb0bdae9f412406c2258f5a9fbb4bef", null ],
    [ "initWithFlipX", "d0/d40/classcocos2d_1_1_flip_x.html#aa5b9899f705c693485c31ecda16382d1", null ]
];