var classcocos2d_1_1_transition_page_turn =
[
    [ "draw", "d0/d41/classcocos2d_1_1_transition_page_turn.html#a0f59730fa0bd109f318e0a18bb4f8945", null ],
    [ "initWithDuration", "d0/d41/classcocos2d_1_1_transition_page_turn.html#a36996f55008e6aff99068eb9b39216ca", null ],
    [ "actionWithSize", "d0/d41/classcocos2d_1_1_transition_page_turn.html#addea7d2e10a39e7b452cb5fc9f4d50b3", null ],
    [ "onEnter", "d0/d41/classcocos2d_1_1_transition_page_turn.html#afc7cfcc21d71b281894ff0800f4a9081", null ],
    [ "onExit", "d0/d41/classcocos2d_1_1_transition_page_turn.html#a9b425b901faa7243c70d90b09db89d15", null ]
];