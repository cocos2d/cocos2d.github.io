var classcocos2d_1_1_rotate_to =
[
    [ "clone", "d0/d71/classcocos2d_1_1_rotate_to.html#a410d648d78354acbad7f5691497d2344", null ],
    [ "reverse", "d0/d71/classcocos2d_1_1_rotate_to.html#a803a9958bc2810431ddd9733450ade68", null ],
    [ "startWithTarget", "d0/d71/classcocos2d_1_1_rotate_to.html#a82f24562dbde467eaa45c5a075678bd3", null ],
    [ "update", "d0/d71/classcocos2d_1_1_rotate_to.html#a751ebb37cca9cecea95c8160529b097c", null ],
    [ "initWithDuration", "d0/d71/classcocos2d_1_1_rotate_to.html#a7102270e9ab94ef9987a6f7b642c1878", null ],
    [ "initWithDuration", "d0/d71/classcocos2d_1_1_rotate_to.html#af5f2451c46850a4ffa9e5919ae38a173", null ],
    [ "calculateAngles", "d0/d71/classcocos2d_1_1_rotate_to.html#a6b3977f9b8075ff10ca6c0be0c1d0ae2", null ]
];