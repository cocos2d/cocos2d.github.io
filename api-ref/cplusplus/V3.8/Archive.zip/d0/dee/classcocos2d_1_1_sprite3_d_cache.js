var classcocos2d_1_1_sprite3_d_cache =
[
    [ "getSpriteData", "d0/dee/classcocos2d_1_1_sprite3_d_cache.html#a1aa469e00421b9ab7e906ab4df65f32d", null ],
    [ "addSprite3DData", "d0/dee/classcocos2d_1_1_sprite3_d_cache.html#a4dfd6617c2d54656ecc978c59ef71371", null ],
    [ "removeSprite3DData", "d0/dee/classcocos2d_1_1_sprite3_d_cache.html#ad879dfcb533b44c2a6e0130d9c279bf8", null ],
    [ "removeAllSprite3DData", "d0/dee/classcocos2d_1_1_sprite3_d_cache.html#a6ef46afce58600e1a02b11792a4d6b32", null ]
];