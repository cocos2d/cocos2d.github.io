var structcocos2d_1_1_font_stroke =
[
    [ "_strokeEnabled", "d0/d74/structcocos2d_1_1_font_stroke.html#acffcef4602af2d8adadf738ab26de7fe", null ],
    [ "_strokeColor", "d0/d74/structcocos2d_1_1_font_stroke.html#aa4c857716538b0f9ec9c068856099012", null ],
    [ "_strokeAlpha", "d0/d74/structcocos2d_1_1_font_stroke.html#a8d10b89b51f25b1fad515941f3682480", null ],
    [ "_strokeSize", "d0/d74/structcocos2d_1_1_font_stroke.html#a80fe1d57d9668ac971250c5b035b4685", null ]
];