var classcocos2d_1_1_transition_slide_in_t =
[
    [ "action", "d0/d85/classcocos2d_1_1_transition_slide_in_t.html#a46330ea90685d8336920ce0790b4eeb0", null ]
];