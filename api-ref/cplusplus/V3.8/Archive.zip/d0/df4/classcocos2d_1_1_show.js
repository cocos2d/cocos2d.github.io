var classcocos2d_1_1_show =
[
    [ "update", "d0/df4/classcocos2d_1_1_show.html#a751ebb37cca9cecea95c8160529b097c", null ],
    [ "reverse", "d0/df4/classcocos2d_1_1_show.html#a355c23dba0746b9b464c68da8d7f91f3", null ],
    [ "clone", "d0/df4/classcocos2d_1_1_show.html#ae3f241bdcd081559145954d9742e9b8d", null ]
];