var classcocos2d_1_1_transition_slide_in_b =
[
    [ "action", "d0/d8c/classcocos2d_1_1_transition_slide_in_b.html#a46330ea90685d8336920ce0790b4eeb0", null ]
];