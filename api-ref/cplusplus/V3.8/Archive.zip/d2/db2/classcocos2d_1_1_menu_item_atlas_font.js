var classcocos2d_1_1_menu_item_atlas_font =
[
    [ "initWithString", "d2/db2/classcocos2d_1_1_menu_item_atlas_font.html#a963497385c55b6bbd23ecb7591a85ee7", null ],
    [ "initWithString", "d2/db2/classcocos2d_1_1_menu_item_atlas_font.html#adadac155b71d69a7fe328748ac63d6e5", null ]
];