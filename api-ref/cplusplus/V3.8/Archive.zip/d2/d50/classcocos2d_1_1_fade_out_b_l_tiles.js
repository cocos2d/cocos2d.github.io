var classcocos2d_1_1_fade_out_b_l_tiles =
[
    [ "testFunc", "d2/d50/classcocos2d_1_1_fade_out_b_l_tiles.html#abf495a9d040973cc672d583463bf5705", null ],
    [ "clone", "d2/d50/classcocos2d_1_1_fade_out_b_l_tiles.html#a531f476bd1db79d915e66ee11a268722", null ]
];