var classcocos2d_1_1ui_1_1_relative_layout_parameter =
[
    [ "RelativeAlign", "dd/df1/group__ui.html#gae919c39d95e11a364c74c35a5a9db089", null ],
    [ "RelativeLayoutParameter", "d2/d04/classcocos2d_1_1ui_1_1_relative_layout_parameter.html#aacc1923389c2c4b1a22f79fee8a68fe6", null ],
    [ "~RelativeLayoutParameter", "d2/d04/classcocos2d_1_1ui_1_1_relative_layout_parameter.html#a53c398db444e5b2074c1bd1adeb89f9f", null ],
    [ "setAlign", "d2/d04/classcocos2d_1_1ui_1_1_relative_layout_parameter.html#a52ccdc614e66974bbc65c3328c42bcce", null ],
    [ "getAlign", "d2/d04/classcocos2d_1_1ui_1_1_relative_layout_parameter.html#ae6a57e334d08718b85cae56003e94fba", null ],
    [ "setRelativeToWidgetName", "d2/d04/classcocos2d_1_1ui_1_1_relative_layout_parameter.html#a53a5f699ce193ca593a4767159593f07", null ],
    [ "getRelativeToWidgetName", "d2/d04/classcocos2d_1_1ui_1_1_relative_layout_parameter.html#a7b10478b7e8a4e5ce9c52af3cee2f3e2", null ],
    [ "setRelativeName", "d2/d04/classcocos2d_1_1ui_1_1_relative_layout_parameter.html#af4c0954e001b53942ac0a58e27f32551", null ],
    [ "getRelativeName", "d2/d04/classcocos2d_1_1ui_1_1_relative_layout_parameter.html#a4e26855cfdf668e7e34d5bd7b912f046", null ],
    [ "createCloneInstance", "d2/d04/classcocos2d_1_1ui_1_1_relative_layout_parameter.html#ab9a94180b0f6fe0f85e1e1eaba7275e1", null ],
    [ "copyProperties", "d2/d04/classcocos2d_1_1ui_1_1_relative_layout_parameter.html#a8e73ca8c52f1c77a5ef98c597937a816", null ]
];