var classcocos2d_1_1_tint_by =
[
    [ "clone", "d2/d6b/classcocos2d_1_1_tint_by.html#a8d601718e4e9c78cb731403299ed3b3a", null ],
    [ "reverse", "d2/d6b/classcocos2d_1_1_tint_by.html#a3f3a6d3bbb4ce025dcccd9f025768516", null ],
    [ "startWithTarget", "d2/d6b/classcocos2d_1_1_tint_by.html#a82f24562dbde467eaa45c5a075678bd3", null ],
    [ "update", "d2/d6b/classcocos2d_1_1_tint_by.html#a751ebb37cca9cecea95c8160529b097c", null ],
    [ "initWithDuration", "d2/d6b/classcocos2d_1_1_tint_by.html#a1d643d1c1b78e5410abae6b8dec2fc37", null ]
];