var classcocos2d_1_1_physics_shape_polygon =
[
    [ "calculateDefaultMoment", "d2/dec/classcocos2d_1_1_physics_shape_polygon.html#ab635aa1c9619cc09bb8cba59759d3636", null ],
    [ "getPoint", "d2/dec/classcocos2d_1_1_physics_shape_polygon.html#a3ed2eec761639b66624aac4278324c63", null ],
    [ "getPoints", "d2/dec/classcocos2d_1_1_physics_shape_polygon.html#a166a90fcef56540fa604f10b03b2e0f2", null ],
    [ "getPointsCount", "d2/dec/classcocos2d_1_1_physics_shape_polygon.html#afde9318ea4512c71607971aa5fccdb72", null ],
    [ "getCenter", "d2/dec/classcocos2d_1_1_physics_shape_polygon.html#a7a770b977fe0a88f032b3fdccbffc186", null ]
];