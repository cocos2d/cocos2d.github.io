var classcocos2d_1_1_particle_galaxy =
[
    [ "initWithTotalParticles", "d2/d13/classcocos2d_1_1_particle_galaxy.html#ac7e269df79e2dd7599ae15c4ec037942", null ]
];