var classcocos2d_1_1_particle_meteor =
[
    [ "initWithTotalParticles", "d2/d67/classcocos2d_1_1_particle_meteor.html#ac7e269df79e2dd7599ae15c4ec037942", null ]
];