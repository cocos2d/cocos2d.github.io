var classcocos2d_1_1_transition_fade_down =
[
    [ "actionWithSize", "d2/d9b/classcocos2d_1_1_transition_fade_down.html#a8b6110c666983421f1e27b7ae7d99b7f", null ]
];