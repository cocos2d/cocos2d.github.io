var classcocos2d_1_1_skew_by =
[
    [ "startWithTarget", "d2/d6c/classcocos2d_1_1_skew_by.html#a82f24562dbde467eaa45c5a075678bd3", null ],
    [ "clone", "d2/d6c/classcocos2d_1_1_skew_by.html#a9ce06c9bdfd313b231e9ac724d68fccb", null ],
    [ "reverse", "d2/d6c/classcocos2d_1_1_skew_by.html#a8272a8f7c713ae35d610531dc8443019", null ],
    [ "initWithDuration", "d2/d6c/classcocos2d_1_1_skew_by.html#ab6f7050540676771f21722a01390e9b7", null ]
];