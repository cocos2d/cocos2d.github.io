var classcocos2d_1_1_physics_joint =
[
    [ "getBodyA", "d2/d8a/classcocos2d_1_1_physics_joint.html#ad86de949d353d8df580f300886947acc", null ],
    [ "getBodyB", "d2/d8a/classcocos2d_1_1_physics_joint.html#a298e83ca31d82b8203d4cb79c2df251d", null ],
    [ "getWorld", "d2/d8a/classcocos2d_1_1_physics_joint.html#a5fc234a129deb3bb2f0995dd2f75cd31", null ],
    [ "getTag", "d2/d8a/classcocos2d_1_1_physics_joint.html#a6089304a20f8f868c1f9443e334ede0a", null ],
    [ "setTag", "d2/d8a/classcocos2d_1_1_physics_joint.html#a42ce1e4178797abb8acd8067e2817df4", null ],
    [ "isEnabled", "d2/d8a/classcocos2d_1_1_physics_joint.html#ae2931e09e0fd8eac15c83f0254b4e4ac", null ],
    [ "setEnable", "d2/d8a/classcocos2d_1_1_physics_joint.html#ad9b4e2583cf89e9ff2822817a5ed5b64", null ],
    [ "isCollisionEnabled", "d2/d8a/classcocos2d_1_1_physics_joint.html#a3d9e56b9042e61347ddf34ed08c18f29", null ],
    [ "setCollisionEnable", "d2/d8a/classcocos2d_1_1_physics_joint.html#a694942c5017a019eb8dcde820e4f7c61", null ],
    [ "removeFormWorld", "d2/d8a/classcocos2d_1_1_physics_joint.html#aec144cd51fe3849efe7602fdad1a6149", null ],
    [ "setMaxForce", "d2/d8a/classcocos2d_1_1_physics_joint.html#a63e2ed60d9ab120f6eab6a1747ba6548", null ],
    [ "getMaxForce", "d2/d8a/classcocos2d_1_1_physics_joint.html#ab8e640e0b398c7f58f89fd930e299122", null ]
];