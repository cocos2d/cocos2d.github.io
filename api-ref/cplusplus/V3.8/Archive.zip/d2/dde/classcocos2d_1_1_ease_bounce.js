var classcocos2d_1_1_ease_bounce =
[
    [ "clone", "d2/dde/classcocos2d_1_1_ease_bounce.html#ad1285f287b85c0174d034f34b3d91b0d", null ],
    [ "reverse", "d2/dde/classcocos2d_1_1_ease_bounce.html#a71740b075c0a15e24bd02591e6721375", null ]
];