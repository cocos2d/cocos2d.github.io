var classcocos2d_1_1_clipping_node =
[
    [ "getStencil", "d2/d06/classcocos2d_1_1_clipping_node.html#a545e199834faea6bf7aabd5691846e6e", null ],
    [ "setStencil", "d2/d06/classcocos2d_1_1_clipping_node.html#a2e0c52184d266848878ec91f2066853b", null ],
    [ "hasContent", "d2/d06/classcocos2d_1_1_clipping_node.html#a95c643c9d9ae1a9978bdbe6c2107f567", null ],
    [ "getAlphaThreshold", "d2/d06/classcocos2d_1_1_clipping_node.html#af8c416dca7231250f7aecb3809106b6c", null ],
    [ "setAlphaThreshold", "d2/d06/classcocos2d_1_1_clipping_node.html#a3c236c3c27d648d5c768628e76610007", null ],
    [ "isInverted", "d2/d06/classcocos2d_1_1_clipping_node.html#aad8e67b937cad74814eb52d88ff1f486", null ],
    [ "setInverted", "d2/d06/classcocos2d_1_1_clipping_node.html#a8280a644967021ca0e88b278d3e52bcc", null ],
    [ "onEnter", "d2/d06/classcocos2d_1_1_clipping_node.html#afc7cfcc21d71b281894ff0800f4a9081", null ],
    [ "onEnterTransitionDidFinish", "d2/d06/classcocos2d_1_1_clipping_node.html#ac20bd0689006e7630c34e221811d068f", null ],
    [ "onExitTransitionDidStart", "d2/d06/classcocos2d_1_1_clipping_node.html#a328672b6902dc610b7e969b2e6423698", null ],
    [ "onExit", "d2/d06/classcocos2d_1_1_clipping_node.html#a9b425b901faa7243c70d90b09db89d15", null ],
    [ "visit", "d2/d06/classcocos2d_1_1_clipping_node.html#a445f8831c456f176e20bbb6a32f27181", null ],
    [ "init", "d2/d06/classcocos2d_1_1_clipping_node.html#aece461389d41c7de591b2bcd99a3e3e2", null ],
    [ "init", "d2/d06/classcocos2d_1_1_clipping_node.html#a81c59844d81af3459f34faa35dfd48d4", null ]
];