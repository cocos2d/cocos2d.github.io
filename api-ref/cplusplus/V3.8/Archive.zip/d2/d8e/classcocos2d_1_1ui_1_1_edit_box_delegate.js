var classcocos2d_1_1ui_1_1_edit_box_delegate =
[
    [ "editBoxEditingDidBegin", "d2/d8e/classcocos2d_1_1ui_1_1_edit_box_delegate.html#a5c851f12139dbe3526eae208de182bf7", null ],
    [ "editBoxEditingDidEnd", "d2/d8e/classcocos2d_1_1ui_1_1_edit_box_delegate.html#a10cf9cfc1880049fa20eb3c209405f21", null ],
    [ "editBoxTextChanged", "d2/d8e/classcocos2d_1_1ui_1_1_edit_box_delegate.html#a658e1c2a1d437db37fab16214f9f21bc", null ],
    [ "editBoxReturn", "d2/d8e/classcocos2d_1_1ui_1_1_edit_box_delegate.html#ae639a1b2950a7166531ce60a8eb338be", null ]
];