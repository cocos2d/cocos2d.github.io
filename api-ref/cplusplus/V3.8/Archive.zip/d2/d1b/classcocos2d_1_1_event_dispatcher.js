var classcocos2d_1_1_event_dispatcher =
[
    [ "EventDispatcher", "d2/d1b/classcocos2d_1_1_event_dispatcher.html#ac34b07e6e793f0468642614b608c82df", null ],
    [ "~EventDispatcher", "d2/d1b/classcocos2d_1_1_event_dispatcher.html#a211adaea3c667264b34f255086766e1c", null ],
    [ "addEventListenerWithSceneGraphPriority", "d2/d1b/classcocos2d_1_1_event_dispatcher.html#a9137cbc969607bc1c0f539155af16f15", null ],
    [ "addEventListenerWithFixedPriority", "d2/d1b/classcocos2d_1_1_event_dispatcher.html#ae5877239d4ae52648513ea729c4b2b60", null ],
    [ "addCustomEventListener", "d2/d1b/classcocos2d_1_1_event_dispatcher.html#ac33b3a84b6512d7d5306d9cba2113bb8", null ],
    [ "removeEventListener", "d2/d1b/classcocos2d_1_1_event_dispatcher.html#acee899a2ab84f14dec80fb837a6073c3", null ],
    [ "removeEventListenersForType", "d2/d1b/classcocos2d_1_1_event_dispatcher.html#a084468e7faa0c5c673f3541896a9b284", null ],
    [ "removeEventListenersForTarget", "d2/d1b/classcocos2d_1_1_event_dispatcher.html#ac911274f3dac1a2fd1ba2d36c575ac11", null ],
    [ "removeCustomEventListeners", "d2/d1b/classcocos2d_1_1_event_dispatcher.html#aba770d1c6f01c84bc4e8a08b5c6eb9e5", null ],
    [ "removeAllEventListeners", "d2/d1b/classcocos2d_1_1_event_dispatcher.html#ad7de6d458a1f7594ae0f666572090353", null ],
    [ "pauseEventListenersForTarget", "d2/d1b/classcocos2d_1_1_event_dispatcher.html#a7489e4ec89702f8cdfaa8ede66703c96", null ],
    [ "resumeEventListenersForTarget", "d2/d1b/classcocos2d_1_1_event_dispatcher.html#a2b22271fe79b6b3def1ca4ccb309caee", null ],
    [ "setPriority", "d2/d1b/classcocos2d_1_1_event_dispatcher.html#ab34f45865fca71da4cb1d04d641dbf08", null ],
    [ "setEnabled", "d2/d1b/classcocos2d_1_1_event_dispatcher.html#a1d3704f44a323433362e7778a4657984", null ],
    [ "isEnabled", "d2/d1b/classcocos2d_1_1_event_dispatcher.html#ae2931e09e0fd8eac15c83f0254b4e4ac", null ],
    [ "dispatchEvent", "d2/d1b/classcocos2d_1_1_event_dispatcher.html#a908d34151247e498f9516baa45e9a8cc", null ],
    [ "dispatchCustomEvent", "d2/d1b/classcocos2d_1_1_event_dispatcher.html#a3bec59b6e5c57c3a02e8e4dde0494f1a", null ]
];