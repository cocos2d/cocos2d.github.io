var structcocos2d_1_1_touches_script_data =
[
    [ "actionType", "d2/dea/structcocos2d_1_1_touches_script_data.html#ad1951eccacb668d1e4e70879c5004240", null ]
];