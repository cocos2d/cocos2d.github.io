var classcocos2d_1_1_event_acceleration =
[
    [ "EventAcceleration", "d4/d99/classcocos2d_1_1_event_acceleration.html#a1ea43bc6d0f17e9bed037464cc2c15f4", null ]
];