var classcocos2d_1_1_event_listener_physics_contact_with_group =
[
    [ "hitTest", "d4/dcf/classcocos2d_1_1_event_listener_physics_contact_with_group.html#a4f1899585593d0c51e1357532a0783b8", null ],
    [ "clone", "d4/dcf/classcocos2d_1_1_event_listener_physics_contact_with_group.html#a84a4c1bc01a48ebd37a1c11dbb1c3f42", null ]
];