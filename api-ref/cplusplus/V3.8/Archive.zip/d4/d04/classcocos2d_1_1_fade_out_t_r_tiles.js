var classcocos2d_1_1_fade_out_t_r_tiles =
[
    [ "testFunc", "d4/d04/classcocos2d_1_1_fade_out_t_r_tiles.html#abf68df7b923c2e9cf84da6a0156edb74", null ],
    [ "turnOnTile", "d4/d04/classcocos2d_1_1_fade_out_t_r_tiles.html#a0747f8ef2c6be0c50236f34717cb1670", null ],
    [ "turnOffTile", "d4/d04/classcocos2d_1_1_fade_out_t_r_tiles.html#af79f527c9d75622afe8ac6ae80c7a4d8", null ],
    [ "transformTile", "d4/d04/classcocos2d_1_1_fade_out_t_r_tiles.html#a43aec034c3d442fb809fc17b887203ab", null ],
    [ "update", "d4/d04/classcocos2d_1_1_fade_out_t_r_tiles.html#a751ebb37cca9cecea95c8160529b097c", null ],
    [ "clone", "d4/d04/classcocos2d_1_1_fade_out_t_r_tiles.html#a323562ff28e83280bed6e4f469dd573e", null ]
];