var classcocos2d_1_1_ease_sine_out =
[
    [ "update", "d4/d85/classcocos2d_1_1_ease_sine_out.html#a751ebb37cca9cecea95c8160529b097c", null ],
    [ "clone", "d4/d85/classcocos2d_1_1_ease_sine_out.html#a781ae30021caf4822f241ba18f675b0d", null ],
    [ "reverse", "d4/d85/classcocos2d_1_1_ease_sine_out.html#ae4358774e2467d56e2d5c2802ec042bd", null ]
];