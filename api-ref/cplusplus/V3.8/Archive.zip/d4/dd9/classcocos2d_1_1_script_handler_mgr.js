var classcocos2d_1_1_script_handler_mgr =
[
    [ "HandlerType", "d4/db3/group__lua.html#ga527ab642971b1269953e766fad0c115e", null ],
    [ "ScriptHandlerMgr", "d4/dd9/classcocos2d_1_1_script_handler_mgr.html#a15c0a8ccd994183f283804a248ab1418", null ],
    [ "~ScriptHandlerMgr", "d4/dd9/classcocos2d_1_1_script_handler_mgr.html#a638ba058495903aded3518fe16dd1134", null ],
    [ "addObjectHandler", "d4/dd9/classcocos2d_1_1_script_handler_mgr.html#a7018f8860ad8522c863030899271c0ff", null ],
    [ "removeObjectHandler", "d4/dd9/classcocos2d_1_1_script_handler_mgr.html#a77eee41644f2d9249340b70b00bd5953", null ],
    [ "getObjectHandler", "d4/dd9/classcocos2d_1_1_script_handler_mgr.html#a6473cc9fbdc7c5af9ded040af4de8148", null ],
    [ "removeObjectAllHandlers", "d4/dd9/classcocos2d_1_1_script_handler_mgr.html#ae0d5503dbc1f8cdf31631abe78737ec3", null ],
    [ "addCustomHandler", "d4/dd9/classcocos2d_1_1_script_handler_mgr.html#adce6755001446f482aca19cc275d4878", null ]
];