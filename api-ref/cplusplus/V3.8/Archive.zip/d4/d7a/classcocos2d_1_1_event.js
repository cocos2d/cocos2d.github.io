var classcocos2d_1_1_event =
[
    [ "Type", "dd/df2/group__base.html#ga1d1cfd8ffb84e947f82999c682b666a7", null ],
    [ "Event", "d4/d7a/classcocos2d_1_1_event.html#a615396a45531c047219d4b99c214a0ed", null ],
    [ "~Event", "d4/d7a/classcocos2d_1_1_event.html#aa28124883bfb17601f85db7e635094b1", null ],
    [ "getType", "d4/d7a/classcocos2d_1_1_event.html#afc641171fb699c1116758176cd3bf4ab", null ],
    [ "stopPropagation", "d4/d7a/classcocos2d_1_1_event.html#a5591305c3b987788eb8ac753710df4b4", null ],
    [ "isStopped", "d4/d7a/classcocos2d_1_1_event.html#a6e468b5d12f6e1cf78a19e381dd22083", null ],
    [ "getCurrentTarget", "d4/d7a/classcocos2d_1_1_event.html#ae901fc82eaab3d9ad2b200987e797869", null ]
];