var classcocos2d_1_1_clipping_rectangle_node =
[
    [ "getClippingRegion", "d4/de8/classcocos2d_1_1_clipping_rectangle_node.html#a615109c861a3259eb57a198746f11bc8", null ],
    [ "setClippingRegion", "d4/de8/classcocos2d_1_1_clipping_rectangle_node.html#abc442e96093ce99a590fecc2b1e8ac7e", null ],
    [ "isClippingEnabled", "d4/de8/classcocos2d_1_1_clipping_rectangle_node.html#aab5d9e7e36178a55b6afaa5388d22e51", null ],
    [ "setClippingEnabled", "d4/de8/classcocos2d_1_1_clipping_rectangle_node.html#abc02408185d7c5abbe20b7a90147087e", null ],
    [ "visit", "d4/de8/classcocos2d_1_1_clipping_rectangle_node.html#a445f8831c456f176e20bbb6a32f27181", null ]
];