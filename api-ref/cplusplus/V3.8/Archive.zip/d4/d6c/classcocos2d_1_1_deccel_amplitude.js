var classcocos2d_1_1_deccel_amplitude =
[
    [ "getRate", "d4/d6c/classcocos2d_1_1_deccel_amplitude.html#a4da2d5e03a1df96d3ec7e1cd09b7242f", null ],
    [ "setRate", "d4/d6c/classcocos2d_1_1_deccel_amplitude.html#add2bcd36c051900d697853155494865b", null ],
    [ "startWithTarget", "d4/d6c/classcocos2d_1_1_deccel_amplitude.html#a82f24562dbde467eaa45c5a075678bd3", null ],
    [ "update", "d4/d6c/classcocos2d_1_1_deccel_amplitude.html#a751ebb37cca9cecea95c8160529b097c", null ],
    [ "clone", "d4/d6c/classcocos2d_1_1_deccel_amplitude.html#ae901bdc45c1951f056ec32de56044a87", null ],
    [ "reverse", "d4/d6c/classcocos2d_1_1_deccel_amplitude.html#a58f7b93c6da3c245d076526eac98f4a8", null ],
    [ "initWithAction", "d4/d6c/classcocos2d_1_1_deccel_amplitude.html#a9856ce8bdba253b88cadfb01ad7b0fc8", null ]
];