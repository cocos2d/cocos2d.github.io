var classcocos2d_1_1_ease_rate_action =
[
    [ "setRate", "d4/d7f/classcocos2d_1_1_ease_rate_action.html#add2bcd36c051900d697853155494865b", null ],
    [ "getRate", "d4/d7f/classcocos2d_1_1_ease_rate_action.html#a4da2d5e03a1df96d3ec7e1cd09b7242f", null ],
    [ "clone", "d4/d7f/classcocos2d_1_1_ease_rate_action.html#a06f2fb443d6641aa5a957c8f293f92c4", null ],
    [ "reverse", "d4/d7f/classcocos2d_1_1_ease_rate_action.html#ad4d2be82570c7785314529052d2e1351", null ],
    [ "initWithAction", "d4/d7f/classcocos2d_1_1_ease_rate_action.html#a25bd4dbe6e7fca1f2ec9640cc2a0f917", null ]
];