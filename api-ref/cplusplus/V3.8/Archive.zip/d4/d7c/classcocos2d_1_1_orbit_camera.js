var classcocos2d_1_1_orbit_camera =
[
    [ "sphericalRadius", "d4/d7c/classcocos2d_1_1_orbit_camera.html#a1cbc738069ecff32096468ec6bd769a0", null ],
    [ "clone", "d4/d7c/classcocos2d_1_1_orbit_camera.html#ab1e140f9a87161db0acf05aaa6f2828d", null ],
    [ "startWithTarget", "d4/d7c/classcocos2d_1_1_orbit_camera.html#a82f24562dbde467eaa45c5a075678bd3", null ],
    [ "update", "d4/d7c/classcocos2d_1_1_orbit_camera.html#a751ebb37cca9cecea95c8160529b097c", null ],
    [ "initWithDuration", "d4/d7c/classcocos2d_1_1_orbit_camera.html#af213e182feb03416d918e9165a34676b", null ]
];