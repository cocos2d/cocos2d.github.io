var classcocos2d_1_1_technique =
[
    [ "addPass", "d4/d38/classcocos2d_1_1_technique.html#affdc631af0ef8f815128b87d4f974444", null ],
    [ "getName", "d4/d38/classcocos2d_1_1_technique.html#a33957ff81d96d5eb86be59fea5034afd", null ],
    [ "getPassByIndex", "d4/d38/classcocos2d_1_1_technique.html#ac6f11323e19237b54ce558f8592c6bf3", null ],
    [ "getPassCount", "d4/d38/classcocos2d_1_1_technique.html#af9ca9aa904d61bc7e9611cb68fd530ee", null ],
    [ "getPasses", "d4/d38/classcocos2d_1_1_technique.html#a4529f20c15ecf5dfa0056945a234b293", null ],
    [ "clone", "d4/d38/classcocos2d_1_1_technique.html#a2c94de96aac759dc92652eb21ee1ebf7", null ]
];