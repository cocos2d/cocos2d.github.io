var classcocos2d_1_1_async_task_pool =
[
    [ "stopTasks", "d4/d56/classcocos2d_1_1_async_task_pool.html#a35fba8571f94e319697dbf0dc09b4ad3", null ],
    [ "enqueue", "d4/d56/classcocos2d_1_1_async_task_pool.html#a26593777c55069ac58073c0f2a586776", null ]
];