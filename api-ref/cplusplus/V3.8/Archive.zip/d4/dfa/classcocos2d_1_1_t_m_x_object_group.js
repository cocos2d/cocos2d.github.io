var classcocos2d_1_1_t_m_x_object_group =
[
    [ "getGroupName", "d4/dfa/classcocos2d_1_1_t_m_x_object_group.html#a61d5023fb6be19c9d7f667e449455a58", null ],
    [ "setGroupName", "d4/dfa/classcocos2d_1_1_t_m_x_object_group.html#a7f2abc230917903c1f2e2b5b3f789cc7", null ],
    [ "getProperty", "d4/dfa/classcocos2d_1_1_t_m_x_object_group.html#a3bf2b5d88b1d8ce4fc7aff4447568803", null ],
    [ "getObject", "d4/dfa/classcocos2d_1_1_t_m_x_object_group.html#aa57718da611d57d8f486ff3866bc6463", null ],
    [ "getPositionOffset", "d4/dfa/classcocos2d_1_1_t_m_x_object_group.html#a6b994753500da2912cd8ecc52f9f6c9d", null ],
    [ "setPositionOffset", "d4/dfa/classcocos2d_1_1_t_m_x_object_group.html#ad9bab0989c4c68fed831a0dbd4ca80e2", null ],
    [ "getProperties", "d4/dfa/classcocos2d_1_1_t_m_x_object_group.html#a4171954e9a2efdcaa8b88190ec026012", null ],
    [ "setProperties", "d4/dfa/classcocos2d_1_1_t_m_x_object_group.html#a59338858883217a7724f79950d261f11", null ],
    [ "getObjects", "d4/dfa/classcocos2d_1_1_t_m_x_object_group.html#aeafacb1c3f214fb02ef67636fa7ceee4", null ],
    [ "setObjects", "d4/dfa/classcocos2d_1_1_t_m_x_object_group.html#a4d0435b662eadb2b31a747323f2c641f", null ]
];