var classcocos2d_1_1_scene =
[
    [ "getDescription", "d4/d5f/classcocos2d_1_1_scene.html#a52b7741f1ccd38d665e153882b7dc0dd", null ],
    [ "getCameras", "d4/d5f/classcocos2d_1_1_scene.html#aa570aadb6071a9e92863bda5e7ff32b3", null ],
    [ "getDefaultCamera", "d4/d5f/classcocos2d_1_1_scene.html#a26beebd88ecf631f3e4565121115496b", null ],
    [ "getLights", "d4/d5f/classcocos2d_1_1_scene.html#a810ff898189ea92822e342dd48aa54c4", null ],
    [ "render", "d4/d5f/classcocos2d_1_1_scene.html#ae0bf1a2d22384b29bd464c668eacec0c", null ],
    [ "removeAllChildren", "d4/d5f/classcocos2d_1_1_scene.html#a5d4871578f13601c557a73fe718a4443", null ],
    [ "addChild", "d4/d5f/classcocos2d_1_1_scene.html#a9bc3fb695690f6b9a722415004eefb24", null ],
    [ "addChild", "d4/d5f/classcocos2d_1_1_scene.html#ad8d11e8724e4ae069df0ef79e36b47b8", null ],
    [ "getPhysicsWorld", "d4/d5f/classcocos2d_1_1_scene.html#a6e832e4a97c7f4428bbcac6cced25988", null ]
];