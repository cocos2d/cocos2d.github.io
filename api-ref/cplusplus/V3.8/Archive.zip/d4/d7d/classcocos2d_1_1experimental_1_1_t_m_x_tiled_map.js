var classcocos2d_1_1experimental_1_1_t_m_x_tiled_map =
[
    [ "getLayer", "d4/d7d/classcocos2d_1_1experimental_1_1_t_m_x_tiled_map.html#ad54516fab72a03e2bffd0a20f9589c37", null ],
    [ "getObjectGroup", "d4/d7d/classcocos2d_1_1experimental_1_1_t_m_x_tiled_map.html#a2adf28eb9287d3d4b41b1578d34b6567", null ],
    [ "getProperty", "d4/d7d/classcocos2d_1_1experimental_1_1_t_m_x_tiled_map.html#a3bf2b5d88b1d8ce4fc7aff4447568803", null ],
    [ "getPropertiesForGID", "d4/d7d/classcocos2d_1_1experimental_1_1_t_m_x_tiled_map.html#a3f9d2f990174d80aea5495ee5a61271b", null ],
    [ "getMapSize", "d4/d7d/classcocos2d_1_1experimental_1_1_t_m_x_tiled_map.html#a0ffe155686196465c4f4b74b1f7c4775", null ],
    [ "setMapSize", "d4/d7d/classcocos2d_1_1experimental_1_1_t_m_x_tiled_map.html#a38c567168ae5bf6bc5d9d7e52dc527a4", null ],
    [ "getTileSize", "d4/d7d/classcocos2d_1_1experimental_1_1_t_m_x_tiled_map.html#a8183787d11f537873e2c161ae3eecd72", null ],
    [ "setTileSize", "d4/d7d/classcocos2d_1_1experimental_1_1_t_m_x_tiled_map.html#a2404fb133c864870cd341806210f7708", null ],
    [ "getMapOrientation", "d4/d7d/classcocos2d_1_1experimental_1_1_t_m_x_tiled_map.html#a0e4bf1494118cd6cf9414822d9200d75", null ],
    [ "setMapOrientation", "d4/d7d/classcocos2d_1_1experimental_1_1_t_m_x_tiled_map.html#a284b5d21a953a54136c7d58b37f49373", null ],
    [ "getObjectGroups", "d4/d7d/classcocos2d_1_1experimental_1_1_t_m_x_tiled_map.html#a653eb709f3759ed3e296adab1c5f0004", null ],
    [ "setObjectGroups", "d4/d7d/classcocos2d_1_1experimental_1_1_t_m_x_tiled_map.html#ab455e9cb4f88e3d3e1926682920e822b", null ],
    [ "getProperties", "d4/d7d/classcocos2d_1_1experimental_1_1_t_m_x_tiled_map.html#a4171954e9a2efdcaa8b88190ec026012", null ],
    [ "setProperties", "d4/d7d/classcocos2d_1_1experimental_1_1_t_m_x_tiled_map.html#a59338858883217a7724f79950d261f11", null ],
    [ "getDescription", "d4/d7d/classcocos2d_1_1experimental_1_1_t_m_x_tiled_map.html#a52b7741f1ccd38d665e153882b7dc0dd", null ]
];