var classcocos2d_1_1_grabber =
[
    [ "Grabber", "d4/de7/classcocos2d_1_1_grabber.html#a4e428c9b45722ccee72b00ef00cbe4c8", null ],
    [ "~Grabber", "d4/de7/classcocos2d_1_1_grabber.html#a8921ec186a9a0c08dc6108bb76b2e4a0", null ],
    [ "grab", "d4/de7/classcocos2d_1_1_grabber.html#a6d5e24168671d4ff0fb310068bc0301b", null ],
    [ "beforeRender", "d4/de7/classcocos2d_1_1_grabber.html#a44af8b7d2ffbb01d116b9dba65e0657e", null ],
    [ "afterRender", "d4/de7/classcocos2d_1_1_grabber.html#a7fd23d48902ce7c76b5bcea031f0a7bb", null ]
];