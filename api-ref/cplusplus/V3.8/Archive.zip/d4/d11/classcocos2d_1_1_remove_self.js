var classcocos2d_1_1_remove_self =
[
    [ "update", "d4/d11/classcocos2d_1_1_remove_self.html#a751ebb37cca9cecea95c8160529b097c", null ],
    [ "clone", "d4/d11/classcocos2d_1_1_remove_self.html#a6b06f17f779a15d1426cd90ff2f7b14b", null ],
    [ "reverse", "d4/d11/classcocos2d_1_1_remove_self.html#aeee2378266846571f02ed519e80828ba", null ],
    [ "init", "d4/d11/classcocos2d_1_1_remove_self.html#a3f9c28a3f7ffdd1035891ac4fc1f2482", null ]
];