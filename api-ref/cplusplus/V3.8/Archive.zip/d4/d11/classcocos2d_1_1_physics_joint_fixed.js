var classcocos2d_1_1_physics_joint_fixed =
[
    [ "createConstraints", "d4/d11/classcocos2d_1_1_physics_joint_fixed.html#a060cddc711deb922bc8c687cdb19bf9d", null ]
];