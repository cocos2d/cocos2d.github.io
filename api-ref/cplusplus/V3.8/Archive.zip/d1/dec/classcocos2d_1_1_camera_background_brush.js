var classcocos2d_1_1_camera_background_brush =
[
    [ "BrushType", "d1/dec/classcocos2d_1_1_camera_background_brush.html#aebd9ad52462d5f4c5f54280321d18bf2", null ],
    [ "getBrushType", "d1/dec/classcocos2d_1_1_camera_background_brush.html#a762901d66b4e5fe73f8acba15308b9e9", null ],
    [ "drawBackground", "d1/dec/classcocos2d_1_1_camera_background_brush.html#a42f9a31003251b31bbd2d2f9423f9e32", null ]
];