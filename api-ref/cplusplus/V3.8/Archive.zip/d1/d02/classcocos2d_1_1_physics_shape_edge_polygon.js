var classcocos2d_1_1_physics_shape_edge_polygon =
[
    [ "getCenter", "d1/d02/classcocos2d_1_1_physics_shape_edge_polygon.html#a7a770b977fe0a88f032b3fdccbffc186", null ],
    [ "getPoints", "d1/d02/classcocos2d_1_1_physics_shape_edge_polygon.html#a166a90fcef56540fa604f10b03b2e0f2", null ],
    [ "getPointsCount", "d1/d02/classcocos2d_1_1_physics_shape_edge_polygon.html#afde9318ea4512c71607971aa5fccdb72", null ]
];