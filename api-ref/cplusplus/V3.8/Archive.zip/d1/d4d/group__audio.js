var group__audio =
[
    [ "cocos2d", "d2/dc0/namespacecocos2d.html", null ],
    [ "AudioEngine", "d0/d75/classcocos2d_1_1experimental_1_1_audio_engine.html", [
      [ "AudioState", "d1/d4d/group__audio.html#ga82cdf833b5d7a90f60d8d8fa638bea9e", null ]
    ] ],
    [ "SimpleAudioEngine", "de/d8f/class_cocos_denshion_1_1_simple_audio_engine.html", [
      [ "preloadBackgroundMusic", "de/d8f/class_cocos_denshion_1_1_simple_audio_engine.html#ab035f8ce722bf134410f617678958f29", null ],
      [ "playBackgroundMusic", "de/d8f/class_cocos_denshion_1_1_simple_audio_engine.html#a636c9f0b8e15dbb1c280073fe225f5fa", null ],
      [ "stopBackgroundMusic", "de/d8f/class_cocos_denshion_1_1_simple_audio_engine.html#a74d37bd6df17f2d99d34e8cf2c0b22ff", null ],
      [ "pauseBackgroundMusic", "de/d8f/class_cocos_denshion_1_1_simple_audio_engine.html#a25c937206ba7087d97b0c56e85e1fac3", null ],
      [ "resumeBackgroundMusic", "de/d8f/class_cocos_denshion_1_1_simple_audio_engine.html#af0fe04e8ef27b7f3977d373dc0248da8", null ],
      [ "rewindBackgroundMusic", "de/d8f/class_cocos_denshion_1_1_simple_audio_engine.html#ae058007c3be6a8c3a2b43493214f2c02", null ],
      [ "willPlayBackgroundMusic", "de/d8f/class_cocos_denshion_1_1_simple_audio_engine.html#a44b9a2297c174f5dd1fd9075612efec0", null ],
      [ "isBackgroundMusicPlaying", "de/d8f/class_cocos_denshion_1_1_simple_audio_engine.html#a660ad99f2e885453e38452cf10140da3", null ],
      [ "getBackgroundMusicVolume", "de/d8f/class_cocos_denshion_1_1_simple_audio_engine.html#a1bd4397a744f30fcc4eb47c51cd6e884", null ],
      [ "setBackgroundMusicVolume", "de/d8f/class_cocos_denshion_1_1_simple_audio_engine.html#a2da08df4c6e0532bd164454a30e42a5b", null ],
      [ "getEffectsVolume", "de/d8f/class_cocos_denshion_1_1_simple_audio_engine.html#add27ad4ce5b9ad888f0cff599cb77263", null ],
      [ "setEffectsVolume", "de/d8f/class_cocos_denshion_1_1_simple_audio_engine.html#a42663c3a84dcba5d19e02d53042c8da7", null ],
      [ "playEffect", "de/d8f/class_cocos_denshion_1_1_simple_audio_engine.html#a2424bf06ce2c54261b8f61aae494e0aa", null ],
      [ "pauseEffect", "de/d8f/class_cocos_denshion_1_1_simple_audio_engine.html#a802ce5e20e8fd6679dd3df01079f7727", null ],
      [ "pauseAllEffects", "de/d8f/class_cocos_denshion_1_1_simple_audio_engine.html#a86837d9364b4227552e51bc1a677d713", null ],
      [ "resumeEffect", "de/d8f/class_cocos_denshion_1_1_simple_audio_engine.html#ada196c827a36bebf37e500010d7725ad", null ],
      [ "resumeAllEffects", "de/d8f/class_cocos_denshion_1_1_simple_audio_engine.html#a326529ac1f25e60a84b414b318edaedf", null ],
      [ "stopEffect", "de/d8f/class_cocos_denshion_1_1_simple_audio_engine.html#a6bc15b339e18055f376ff96846b43eb1", null ],
      [ "stopAllEffects", "de/d8f/class_cocos_denshion_1_1_simple_audio_engine.html#a54c8e6c6fc6baa94b32dd05f9dab22cb", null ],
      [ "preloadEffect", "de/d8f/class_cocos_denshion_1_1_simple_audio_engine.html#a102749e687b918490873b3c0fddd9f83", null ],
      [ "unloadEffect", "de/d8f/class_cocos_denshion_1_1_simple_audio_engine.html#abe3b3e9916ba091b2da77f8fe9c64b06", null ]
    ] ],
    [ "AudioState", "d1/d4d/group__audio.html#ga82cdf833b5d7a90f60d8d8fa638bea9e", null ]
];