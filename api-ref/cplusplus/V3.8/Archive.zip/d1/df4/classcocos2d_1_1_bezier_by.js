var classcocos2d_1_1_bezier_by =
[
    [ "clone", "d1/df4/classcocos2d_1_1_bezier_by.html#a97c610b468ff7bfc09f8711f87094763", null ],
    [ "reverse", "d1/df4/classcocos2d_1_1_bezier_by.html#aa8b91bfc9a737173b708e54f6d729d14", null ],
    [ "startWithTarget", "d1/df4/classcocos2d_1_1_bezier_by.html#a82f24562dbde467eaa45c5a075678bd3", null ],
    [ "update", "d1/df4/classcocos2d_1_1_bezier_by.html#a751ebb37cca9cecea95c8160529b097c", null ],
    [ "initWithDuration", "d1/df4/classcocos2d_1_1_bezier_by.html#a9b5de086d4e441ce0e265b1c934000e4", null ]
];