var classcocos2d_1_1_event_listener_controller =
[
    [ "checkAvailable", "d1/dc4/classcocos2d_1_1_event_listener_controller.html#ab93f0dcb45008d86dd3d2b93298f0ae4", null ],
    [ "clone", "d1/dc4/classcocos2d_1_1_event_listener_controller.html#a9b65833b21fd1df409a44a4e36bb0d81", null ]
];