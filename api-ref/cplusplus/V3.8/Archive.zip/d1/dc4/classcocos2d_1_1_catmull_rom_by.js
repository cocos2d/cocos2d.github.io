var classcocos2d_1_1_catmull_rom_by =
[
    [ "initWithDuration", "d1/dc4/classcocos2d_1_1_catmull_rom_by.html#a369f2545988ed3bf44525f05a987a495", null ],
    [ "clone", "d1/dc4/classcocos2d_1_1_catmull_rom_by.html#a4e67a0ca2c9ab7268bb393620468592a", null ],
    [ "reverse", "d1/dc4/classcocos2d_1_1_catmull_rom_by.html#aae15ad07031b09842a57fa6cb6b73e67", null ]
];