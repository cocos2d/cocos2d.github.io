var classcocos2d_1_1_action_manager =
[
    [ "addAction", "d1/d88/classcocos2d_1_1_action_manager.html#a84f6880cc8a4386e384ed62bf5cca8ab", null ],
    [ "removeAllActions", "d1/d88/classcocos2d_1_1_action_manager.html#a4bd184dd9637bcdd256e589021ee576d", null ],
    [ "removeAllActionsFromTarget", "d1/d88/classcocos2d_1_1_action_manager.html#afba09555106bd84e9c7c8f42a4189bb3", null ],
    [ "removeAction", "d1/d88/classcocos2d_1_1_action_manager.html#afb8d32502ccf549ad954c8fd36b0b778", null ],
    [ "removeActionByTag", "d1/d88/classcocos2d_1_1_action_manager.html#a8cd32be457834dbd0f7c9b29f402b74b", null ],
    [ "removeAllActionsByTag", "d1/d88/classcocos2d_1_1_action_manager.html#a1946b5e3c23a605110899d164f3e4d42", null ],
    [ "removeActionsByFlags", "d1/d88/classcocos2d_1_1_action_manager.html#a9cffaf47f0c82911a6aca78be1305993", null ],
    [ "getActionByTag", "d1/d88/classcocos2d_1_1_action_manager.html#ae5cf1ae4e0854350c2d99bd681bb0bfb", null ],
    [ "getNumberOfRunningActionsInTarget", "d1/d88/classcocos2d_1_1_action_manager.html#a4769fa9d7e880cc9e73f28dcddd23e8b", null ],
    [ "numberOfRunningActionsInTarget", "d1/d88/classcocos2d_1_1_action_manager.html#a1b1ce44ccd34a90e5013bf97fc8fe951", null ],
    [ "pauseTarget", "d1/d88/classcocos2d_1_1_action_manager.html#ab9dabba1ff6258f203c516dc3a6ec02f", null ],
    [ "resumeTarget", "d1/d88/classcocos2d_1_1_action_manager.html#a6d2260037c0d29d286fd78947c492424", null ],
    [ "pauseAllRunningActions", "d1/d88/classcocos2d_1_1_action_manager.html#a0101dea54a7077fda7874be20e26f1ee", null ],
    [ "resumeTargets", "d1/d88/classcocos2d_1_1_action_manager.html#a52a8856ea3a3332afe4b90cc3b400c63", null ],
    [ "update", "d1/d88/classcocos2d_1_1_action_manager.html#a2d15c24b9636f137cfe15a0db9a47c0f", null ]
];