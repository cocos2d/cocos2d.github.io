var classcocos2d_1_1_layer_color =
[
    [ "changeWidth", "d1/de8/classcocos2d_1_1_layer_color.html#afe91e0e12a498c2680ec5b789c545a5c", null ],
    [ "changeHeight", "d1/de8/classcocos2d_1_1_layer_color.html#a60b4130d8991dec4d860834913bfee93", null ],
    [ "changeWidthAndHeight", "d1/de8/classcocos2d_1_1_layer_color.html#a4e77da24a712426823dc29d2e66d2caa", null ],
    [ "draw", "d1/de8/classcocos2d_1_1_layer_color.html#a0f59730fa0bd109f318e0a18bb4f8945", null ],
    [ "setContentSize", "d1/de8/classcocos2d_1_1_layer_color.html#aa750885596f28a27cb177038ed43a543", null ],
    [ "getBlendFunc", "d1/de8/classcocos2d_1_1_layer_color.html#aad7b51987b24a49e377383a6c00ed522", null ],
    [ "setBlendFunc", "d1/de8/classcocos2d_1_1_layer_color.html#a06dc216f9a20530f595d680177dece65", null ],
    [ "getDescription", "d1/de8/classcocos2d_1_1_layer_color.html#a52b7741f1ccd38d665e153882b7dc0dd", null ]
];