var structcocos2d_1_1_touch_script_data =
[
    [ "actionType", "d1/d67/structcocos2d_1_1_touch_script_data.html#ad1951eccacb668d1e4e70879c5004240", null ]
];