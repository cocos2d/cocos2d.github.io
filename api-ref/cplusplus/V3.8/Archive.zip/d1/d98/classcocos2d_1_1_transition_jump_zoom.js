var classcocos2d_1_1_transition_jump_zoom =
[
    [ "onEnter", "d1/d98/classcocos2d_1_1_transition_jump_zoom.html#afc7cfcc21d71b281894ff0800f4a9081", null ]
];