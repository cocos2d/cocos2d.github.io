var classcocos2d_1_1_call_func_n =
[
    [ "clone", "d3/d64/classcocos2d_1_1_call_func_n.html#ac3c689b89f6000f2a1c955a69b3b5dd9", null ],
    [ "execute", "d3/d64/classcocos2d_1_1_call_func_n.html#acc52fddbab2ce2dc6ec9af13a9dd94aa", null ],
    [ "initWithFunction", "d3/d64/classcocos2d_1_1_call_func_n.html#a488f30755023e0eb134fc9929bf11416", null ],
    [ "initWithTarget", "d3/d64/classcocos2d_1_1_call_func_n.html#a46727bf855e98dfdf41ac985c7a31f48", null ]
];