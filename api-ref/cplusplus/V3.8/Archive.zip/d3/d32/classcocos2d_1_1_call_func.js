var classcocos2d_1_1_call_func =
[
    [ "execute", "d3/d32/classcocos2d_1_1_call_func.html#ad5f7eb65ad7e29b7cf8fc85a5f445951", null ],
    [ "getTargetCallback", "d3/d32/classcocos2d_1_1_call_func.html#ac4db606b80a68788ec4ef0f44cb380ce", null ],
    [ "setTargetCallback", "d3/d32/classcocos2d_1_1_call_func.html#a3d2882f3aec50171125e0397d7a93791", null ],
    [ "update", "d3/d32/classcocos2d_1_1_call_func.html#a751ebb37cca9cecea95c8160529b097c", null ],
    [ "reverse", "d3/d32/classcocos2d_1_1_call_func.html#a8d36cb6c94896f950aa87036a605ce3d", null ],
    [ "clone", "d3/d32/classcocos2d_1_1_call_func.html#a8a91dd8e46f6d837b47a0b4f33380ec3", null ],
    [ "initWithTarget", "d3/d32/classcocos2d_1_1_call_func.html#abcb244710b443457ab25b4aac0bab5c9", null ],
    [ "initWithFunction", "d3/d32/classcocos2d_1_1_call_func.html#af4a0d97ba7894fd7e79ae074872a08c1", null ]
];