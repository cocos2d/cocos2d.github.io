var classcocos2d_1_1_transition_scene_oriented =
[
    [ "initWithDuration", "d3/db8/classcocos2d_1_1_transition_scene_oriented.html#ab7f1c87b4dd4520c0efd7114f2112299", null ]
];