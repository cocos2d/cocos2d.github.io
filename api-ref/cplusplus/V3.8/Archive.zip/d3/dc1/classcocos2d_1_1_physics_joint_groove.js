var classcocos2d_1_1_physics_joint_groove =
[
    [ "getGrooveA", "d3/dc1/classcocos2d_1_1_physics_joint_groove.html#a8f5d3d9bdbae6492a8bb84548818283f", null ],
    [ "setGrooveA", "d3/dc1/classcocos2d_1_1_physics_joint_groove.html#a28d8bec3ca3118697e39474de11e8a35", null ],
    [ "getGrooveB", "d3/dc1/classcocos2d_1_1_physics_joint_groove.html#a468ea0dbb25fd8d9193f17a141c0b51a", null ],
    [ "setGrooveB", "d3/dc1/classcocos2d_1_1_physics_joint_groove.html#a2cf9098dfba6c3aea94d9e8fbf9b0fa2", null ],
    [ "getAnchr2", "d3/dc1/classcocos2d_1_1_physics_joint_groove.html#a3b206c1812fc4cceff8c39a454bcbce8", null ],
    [ "setAnchr2", "d3/dc1/classcocos2d_1_1_physics_joint_groove.html#adafe8a35a4c61c30de65994c11d4b9f5", null ],
    [ "createConstraints", "d3/dc1/classcocos2d_1_1_physics_joint_groove.html#a060cddc711deb922bc8c687cdb19bf9d", null ]
];