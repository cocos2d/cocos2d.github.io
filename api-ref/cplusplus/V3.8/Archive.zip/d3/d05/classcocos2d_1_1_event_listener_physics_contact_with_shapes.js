var classcocos2d_1_1_event_listener_physics_contact_with_shapes =
[
    [ "hitTest", "d3/d05/classcocos2d_1_1_event_listener_physics_contact_with_shapes.html#a4f1899585593d0c51e1357532a0783b8", null ],
    [ "clone", "d3/d05/classcocos2d_1_1_event_listener_physics_contact_with_shapes.html#ab861c9a54600730659b3bbaeee2def26", null ]
];