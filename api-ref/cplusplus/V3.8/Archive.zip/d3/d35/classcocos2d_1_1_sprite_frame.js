var classcocos2d_1_1_sprite_frame =
[
    [ "getRectInPixels", "d3/d35/classcocos2d_1_1_sprite_frame.html#a0349781e18653af097fed00005941a7d", null ],
    [ "setRectInPixels", "d3/d35/classcocos2d_1_1_sprite_frame.html#adf4f598ed861ce4465b8a61ab082c16a", null ],
    [ "isRotated", "d3/d35/classcocos2d_1_1_sprite_frame.html#a77fc923d4b7ccb127452445069f76e6c", null ],
    [ "setRotated", "d3/d35/classcocos2d_1_1_sprite_frame.html#ade5602063671778d01e7234a31f42357", null ],
    [ "getRect", "d3/d35/classcocos2d_1_1_sprite_frame.html#aeee3d2abd32c4e1776154787a57f4d25", null ],
    [ "setRect", "d3/d35/classcocos2d_1_1_sprite_frame.html#af062da89d2035532c1aaa875cbc72001", null ],
    [ "getOffsetInPixels", "d3/d35/classcocos2d_1_1_sprite_frame.html#a223fb03c82b74bb7e49d3ed9f14fe86f", null ],
    [ "setOffsetInPixels", "d3/d35/classcocos2d_1_1_sprite_frame.html#ab5679d2cd4bccbb7b37b8cfc8d3c191b", null ],
    [ "getOriginalSizeInPixels", "d3/d35/classcocos2d_1_1_sprite_frame.html#a826bae57fd87491860f0b6a24daeb5c1", null ],
    [ "setOriginalSizeInPixels", "d3/d35/classcocos2d_1_1_sprite_frame.html#a04405e9ee2aaf04ea849a215be8463b8", null ],
    [ "getOriginalSize", "d3/d35/classcocos2d_1_1_sprite_frame.html#a47ca45a996e4a655dd8de8cf5a47c1d9", null ],
    [ "setOriginalSize", "d3/d35/classcocos2d_1_1_sprite_frame.html#a810f885645646fe3557da0250b90714f", null ],
    [ "getTexture", "d3/d35/classcocos2d_1_1_sprite_frame.html#af656511d1e209d0c558372651fc4b64b", null ],
    [ "setTexture", "d3/d35/classcocos2d_1_1_sprite_frame.html#a1e2af5ae957e261dc365df2eeec7f6ef", null ],
    [ "getOffset", "d3/d35/classcocos2d_1_1_sprite_frame.html#aee5d04a7e1c2fd6ce05680a9b7b5ed21", null ],
    [ "setOffset", "d3/d35/classcocos2d_1_1_sprite_frame.html#a29281a4383cf4969e179415e3250ef02", null ],
    [ "clone", "d3/d35/classcocos2d_1_1_sprite_frame.html#ad9cefeff76bfdd886037673453362a92", null ],
    [ "initWithTexture", "d3/d35/classcocos2d_1_1_sprite_frame.html#a5ed7f46aeebf706ccba875cb0008c2a9", null ],
    [ "initWithTextureFilename", "d3/d35/classcocos2d_1_1_sprite_frame.html#a8280f31b301349e21c23f7b48def8ef3", null ],
    [ "initWithTexture", "d3/d35/classcocos2d_1_1_sprite_frame.html#a801075187a9ad692d91d3e231370247e", null ],
    [ "initWithTextureFilename", "d3/d35/classcocos2d_1_1_sprite_frame.html#a95a30a5650aa5f1570d3606ed9c67a81", null ]
];