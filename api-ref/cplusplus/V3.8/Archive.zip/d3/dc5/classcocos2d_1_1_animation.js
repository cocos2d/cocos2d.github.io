var classcocos2d_1_1_animation =
[
    [ "addSpriteFrame", "d3/dc5/classcocos2d_1_1_animation.html#ae4ea388b484d5ace15ba83f43d24904a", null ],
    [ "addSpriteFrameWithFile", "d3/dc5/classcocos2d_1_1_animation.html#ac6667179c86390ff2f408a526bda3777", null ],
    [ "addSpriteFrameWithFileName", "d3/dc5/classcocos2d_1_1_animation.html#a7f62acedbcf610fd23154f27f3a4cafa", null ],
    [ "addSpriteFrameWithTexture", "d3/dc5/classcocos2d_1_1_animation.html#a9c1f056a18c4bcc8e23c84eabf21b55e", null ],
    [ "getTotalDelayUnits", "d3/dc5/classcocos2d_1_1_animation.html#a516af2c8494a17dbba1863c5130da7b1", null ],
    [ "setDelayPerUnit", "d3/dc5/classcocos2d_1_1_animation.html#aec90e838c7a4a08cec45f8388d85c09d", null ],
    [ "getDelayPerUnit", "d3/dc5/classcocos2d_1_1_animation.html#a8a0f12e7ba5d194022160b7cb62b948d", null ],
    [ "getDuration", "d3/dc5/classcocos2d_1_1_animation.html#a137f89ce7c16849a8e94ab656e67f406", null ],
    [ "getFrames", "d3/dc5/classcocos2d_1_1_animation.html#ab506b5d13a31a3f14c220b56d36fc3d2", null ],
    [ "setFrames", "d3/dc5/classcocos2d_1_1_animation.html#abb5b9d8889afe18168674eb77ad6f885", null ],
    [ "getRestoreOriginalFrame", "d3/dc5/classcocos2d_1_1_animation.html#a5895d4d3cbfb9d1290d969373b665f0a", null ],
    [ "setRestoreOriginalFrame", "d3/dc5/classcocos2d_1_1_animation.html#a9d88104c3cb0e3047802780ed779f752", null ],
    [ "getLoops", "d3/dc5/classcocos2d_1_1_animation.html#a045fd8edb336c832e2ba6651436e191a", null ],
    [ "setLoops", "d3/dc5/classcocos2d_1_1_animation.html#a2d39129f5b5a48287d0e7219fbffa801", null ],
    [ "clone", "d3/dc5/classcocos2d_1_1_animation.html#ad73a492e37441a5b6e24c8ac412f9980", null ],
    [ "init", "d3/dc5/classcocos2d_1_1_animation.html#aee8048628ff2b5c026c9e15acdcaacb8", null ],
    [ "initWithSpriteFrames", "d3/dc5/classcocos2d_1_1_animation.html#af8cf019894045bfbaa3ae04c58ab3736", null ],
    [ "initWithAnimationFrames", "d3/dc5/classcocos2d_1_1_animation.html#a88e32f79fe519db97f13169b089e8aed", null ]
];