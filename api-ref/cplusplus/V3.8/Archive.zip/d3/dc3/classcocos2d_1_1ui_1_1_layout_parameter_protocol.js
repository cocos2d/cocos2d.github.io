var classcocos2d_1_1ui_1_1_layout_parameter_protocol =
[
    [ "~LayoutParameterProtocol", "d3/dc3/classcocos2d_1_1ui_1_1_layout_parameter_protocol.html#a0e185b96b71be9dcd5f9d98de8536f0b", null ],
    [ "getLayoutParameter", "d3/dc3/classcocos2d_1_1ui_1_1_layout_parameter_protocol.html#a04393064f64fe3b4d50f227282d8a8f5", null ]
];