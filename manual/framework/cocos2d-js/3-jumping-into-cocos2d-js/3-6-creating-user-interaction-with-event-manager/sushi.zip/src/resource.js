var res = {
    BackGround_png : "res/background.png",
    Start_N_png : "res/start_N.png",
    Start_S_png : "res/start_S.png",
    Sushi_plist : "res/sushi.plist",
    Sushi_png : "res/sushi.png"
};

var g_resources = [];
for (var i in res) {
    g_resources.push(res[i]);
}